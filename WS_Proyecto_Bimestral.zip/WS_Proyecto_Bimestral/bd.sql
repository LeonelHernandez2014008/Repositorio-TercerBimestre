/*
SQLyog Ultimate v9.63 
MySQL - 5.5.8-log : Database - db_turismo
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_turismo` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_turismo`;

/*Table structure for table `hoteles` */

DROP TABLE IF EXISTS `hoteles`;

CREATE TABLE `hoteles` (
  `id_Hotel` int(128) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(255) DEFAULT NULL,
  `Ubicacion` varchar(255) DEFAULT NULL,
  `Precios` varchar(255) DEFAULT NULL,
  `Habitaciones` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_Hotel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hoteles` */

/*Table structure for table `mensajes` */

DROP TABLE IF EXISTS `mensajes`;

CREATE TABLE `mensajes` (
  `id_Mensaje` int(255) NOT NULL AUTO_INCREMENT,
  `Mensaje` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id_Mensaje`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `mensajes` */

/*Table structure for table `municipalidad` */

DROP TABLE IF EXISTS `municipalidad`;

CREATE TABLE `municipalidad` (
  `id_Municipalidad` int(255) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(128) DEFAULT NULL,
  `ubicacion` varchar(128) DEFAULT NULL,
  `id_Mensaje` int(255) DEFAULT NULL,
  `id_SitioTuristico` int(255) DEFAULT NULL,
  PRIMARY KEY (`id_Municipalidad`),
  KEY `fk_id_Mensaje` (`id_Mensaje`),
  KEY `fk_id_SitioTuristico` (`id_SitioTuristico`),
  CONSTRAINT `fk_id_Mensaje` FOREIGN KEY (`id_Mensaje`) REFERENCES `mensajes` (`id_Mensaje`),
  CONSTRAINT `fk_id_SitioTuristico` FOREIGN KEY (`id_SitioTuristico`) REFERENCES `sitiosturisticos` (`id_SitioTuristico`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `municipalidad` */

/*Table structure for table `roles` */

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id_Rol` int(255) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(128) DEFAULT NULL,
  `Descripcion` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id_Rol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `roles` */

/*Table structure for table `sitiosturisticos` */

DROP TABLE IF EXISTS `sitiosturisticos`;

CREATE TABLE `sitiosturisticos` (
  `id_SitioTuristico` int(128) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(255) DEFAULT NULL,
  `Lugar` varchar(255) DEFAULT NULL,
  `Imagen_Principal` varchar(255) DEFAULT NULL,
  `Imagenes` varchar(255) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `Comentarios` varchar(255) DEFAULT NULL,
  `id_Hotel` int(255) DEFAULT NULL,
  PRIMARY KEY (`id_SitioTuristico`),
  KEY `fk_id_Hotel` (`id_Hotel`),
  CONSTRAINT `fk_id_Hotel` FOREIGN KEY (`id_Hotel`) REFERENCES `hoteles` (`id_Hotel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `sitiosturisticos` */

/*Table structure for table `usuarios` */

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id_Usuario` int(255) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(255) DEFAULT NULL,
  `correo` varchar(128) DEFAULT NULL,
  `nick` varchar(128) DEFAULT NULL,
  `contraseña` varchar(128) DEFAULT NULL,
  `id_Rol` int(255) DEFAULT NULL,
  PRIMARY KEY (`id_Usuario`),
  KEY `fk_id_Rol` (`id_Rol`),
  CONSTRAINT `fk_id_Rol` FOREIGN KEY (`id_Rol`) REFERENCES `roles` (`id_Rol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `usuarios` */

/* Procedure structure for procedure `sp_autenticarUsuario` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_autenticarUsuario` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_autenticarUsuario`(IN _nick VARCHAR(128),IN _contrasena VARCHAR(128))
BEGIN
	SELECT nombre,correo,nick FROM usuario WHERE usuario.`nick`=_nick AND usuario.`contraseña`=MD5(_contrasena);
    END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_listacontactos` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_listacontactos` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listacontactos`(IN _idUsuario INT)
BEGIN
	SELECT contacto.idContacto,contacto.nombre,contacto.correo,contacto.direccion,contacto.nombre,contacto.telefonoCasa,contacto.telefonoMovil,usuario.nombre AS usuario,usuario.idUsuario FROM contacto 
	LEFT JOIN usuario ON usuario.idUsuario=contacto.idUsuario 
	WHERE usuario.idUsuario=_idUsuario;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_listaSitioTuristico` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_listaSitioTuristico` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listaSitioTuristico`(IN _id_Hotel INT)
BEGIN
	SELECT sitiosturisticos.id_SitioTuristico,sitiosturisticos.Nombre,sitiosturisticos.Lugar,sitiosturisticos.Imagen_Principal,sitiosturisticos.Imagenes,sitiosturisticos.Descripcion,sitiosturisticos.Comentarios,hoteles.Nombre AS hoteles,hoteles.id_Hotel FROM sitiosturisticos 
	LEFT JOIN hoteles ON hoteles.id_Hotel=sitiosturisticos.id_SitioTuristico 
	WHERE hoteles.id_Hotel=_id_Hotel;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_listaUsuarios` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_listaUsuarios` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listaUsuarios`(IN _id_Rol INT)
BEGIN
	SELECT usuarios.id_Usuario,usuarios.Nombre,usuarios.correo,usuarios.nick,usuarios.contraseña,roles.Nombre AS roles,roles.id_Rol FROM usuarios 
	LEFT JOIN roles ON roles.id_Rol=usuarios.id_Rol 
	WHERE roles.id_Rol=_id_Rol;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_registroUsuario` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_registroUsuario` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registroUsuario`(IN _nombre VARCHAR(128),IN _correo VARCHAR(128),IN _nick VARCHAR(128),_contraseña VARCHAR(128))
BEGIN
	INSERT INTO usuario VALUES(NULL,_nombre,_correo,_nick,MD5(_contraseña));
    END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
