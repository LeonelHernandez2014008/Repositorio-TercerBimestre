modulo.exports=function(app){
	return{
		add:function(req,res){
			var pool = app.get('pool')
			pool.getConnection(function(err,connection){
				if(err){
					connection.release();
					res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
				}
				connection.query("INSERT INTO hotel VALUES (NULL,'"+req.body.nombre+"','"+req.body.ubicacion+"','"+req.body.precios+"','"+req.body.habitaciones+"');", function(err, row){
					if(err)
						throw err;
					else
						res.json({"mensaje":"Hotel Agregado"});
					connection.release();	
			});
		},
		delete:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("Delete from hotel where id_Hotel="+req.body.id_Hotel, function(err, row){
					if(err)
						throw err;
					else
						res.json({"mensaje":"hotel eliminado"});
					connection.release();	
				});
			});	
		},
		list:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("Select * from hotel where id_Hotel="+req.query.id_Hotel, function(err, row){
					if(err)
						throw err;
					else
						res.json(row);
					connection.release();	
				});
			});	
		},
		edit:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("UPDATE hotel set nombre='"+req.body.nombre+"',ubicacion="+req.body.ubicacion+",precios="+req.body.precios+",habitaciones='"+req.body.habitaciones+"', where id_Hotel="+req.body.id_Hotel, function(err, row){
					if(err)
						throw err;
					else
						res.json({"mensaje":"Hotel editado"});
					connection.release();	
				});
			});	
		}
	}
}