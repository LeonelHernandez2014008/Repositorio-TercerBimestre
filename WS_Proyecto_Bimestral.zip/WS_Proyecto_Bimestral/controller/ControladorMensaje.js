modulo.exports=function(app){
	return{
		add:function(req,res){
			var pool = app.get('pool')
			pool.getConnection(function(err,connection){
				if(err){
					connection.release();
					res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
				}
				connection.query("INSERT INTO mensaje VALUES (NULL,'"+req.body.mensaje+"');", function(err, row){
					if(err)
						throw err;
					else
						res.json({"mensaje":"Mensaje Enviado"});
					connection.release();	
			});
		},
		delete:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("Delete from mensaje where id_Mensaje="+req.body.id_Mensaje, function(err, row){
					if(err)
						throw err;
					else
						res.json({"mensaje":"mensaje eliminado"});
					connection.release();	
				});
			});	
		},
		list:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("Select * from mensaje where id_Mensaje="+req.query.id_Mensaje, function(err, row){
					if(err)
						throw err;
					else
						res.json(row);
					connection.release();	
				});
			});	
		},
		edit:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("UPDATE mensaje set mensaje='"+req.body.mensaje+"', function(err, row){
					if(err)
						throw err;
					else
						res.json({"mensaje":"Mensaje editado"});
					connection.release();	
				});
			});	
		}
	}
}