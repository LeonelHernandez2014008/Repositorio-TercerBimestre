module.exports=function(app){
	return {
		add:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("INSERT INTO municipalidad VALUES (NULL,'"+req.body.nombre+"','"+req.body.ubicacion+"','"+req.body.id_Mensaje+"','"+req.body.id_SitioTuristico+"');", function(err, row){
					if(err)
						throw err;
					else
						res.json({"mensaje":" Municcipalidad Agregado"});
					connection.release();	
				});
			});	
		},
		delete:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("Delete from municipalidad where idContacto="+req.body.id_Municipalidad, function(err, row){
					if(err)
						throw err;
					else
						res.json({"mensaje":"Municcipalidad eliminado"});
					connection.release();	
				});
			});	
		},
		list:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("Select * from municipalidad where id_Municipalidad="+req.query.id_Municipalidad, function(err, row){
					if(err)
						throw err;
					else
						res.json(row);
					connection.release();	
				});
			});	
		},
		edit:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("UPDATE municipalidad set nombre='"+req.body.nombre+"',ubicacion="+req.body.ubicacion+",where id_Mensaje="+req.body.id_Mensaje", where id_SitioTuristico="+req.body.id_SitioTuristico"', function(err, row){
					if(err)
						throw err;
					else
						res.json({"mensaje":"Municipalidad editado"});
					connection.release();	
				});
			});	
		}
	}
}