module.exports=function(app){
	return {
		add:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("INSERT INTO sitioTuristico VALUES (NULL,'"+req.body.nombre+"','"+req.body.lugar+"','"+req.body.imagen_Principal+"','"+req.imagenes+"','"+req.body.descripcion+"','"+req.body.comentarios"','"+req.body.id_Hotel+"');", function(err, row){
					if(err)
						throw err;
					else
						res.json({"mensaje":"Sitio Turistico Agregado"});
					connection.release();	
				});
			});	
		},
		delete:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("Delete from sitioTuristico where id_SitioTuristico="+req.body.id_SitioTuristico, function(err, row){
					if(err)
						throw err;
					else
						res.json({"mensaje":"Sitio Turistico eliminado"});
					connection.release();	
				});
			});	
		},
		list:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("Select * from sitioTuristico where id_SitioTuristico="+req.query.id_SitioTuristico, function(err, row){
					if(err)
						throw err;
					else
						res.json(row);
					connection.release();	
				});
			});	
		},
		edit:function(req,res){
			var pool=app.get('pool');
			pool.getConnection(function(err,connection){
				if(err){
                    connection.release();
                    res.json({"code" : 100, "status" : "Error al conectar a la base de datos"});
                }
				connection.query("UPDATE sitioTuristico set nombre='"+req.body.nombre+"',lugar="+req.body.lugar+",Imagen Principal="+req.body.imagen_Principal+",imagenes='"+req.body.imagenes+"',descripcion='"+req.body.descripcion+"',comentarios='"+req.body.comentarios+"', where id_Hotel="+req.body.id_Hotel, function(err, row){
					if(err)
						throw err;
					else
						res.json({"mensaje":"Sitio Turistico editado"});
					connection.release();	
				});
			});	
		}
	}
}