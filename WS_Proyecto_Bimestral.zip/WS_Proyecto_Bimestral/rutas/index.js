var ruta=require('express').Router();
module.exports=(function(app){
	var usuario=require('../controller/ControladorUsuario.js')(app);
	var contacto=require('../controller/ControladorContacto.js')(app);
	ruta.get('/',function(peticion,respuesta){
		respuesta.send("Servicio iniciado");
	});
	
	/*
		Rutas para Usuario
	*/
	ruta.post('/usuario/registro',usuario.registro);
	ruta.post('/usuario/login',usuario.login);
	/*
		Rutas para Hoteles
	*/
	ruta.get('/hoteles',hoteles.list);
	ruta.post('/hoteles',hoteles.add);
	ruta.put('/hoteles',hoteles.edit);
	ruta.delete('/hoteles',hoteles.delete);
	
	/*
		Rutas para Municipalidad
	*/
	ruta.get('/Municipalidad',Municipalidad.list);
	ruta.post('/Municipalidad',Municipalidad.add);
	ruta.put('/Municipalidad',Municipalidad.edit);
	ruta.delete('/Municipalidad',Municipalidad.delete);
	
	/*
		Rutas para SitioTuristico
	*/
	ruta.get('/SitioTuristico',SitioTuristico.list);
	ruta.post('/SitioTuristico',SitioTuristico.add);
	ruta.put('/SitioTuristico',SitioTuristico.edit);
	ruta.delete('/SitioTuristico',SitioTuristico.delete);

	/*
		Rutas para Mensaje
	*/
	ruta.get('/Mensaje',Mensaje.list);
	ruta.post('/Mensaje',Mensaje.add);
	ruta.put('/Mensaje',Mensaje.edit);
	ruta.delete('/Mensaje',Mensaje.delete);
	
	return ruta;
});